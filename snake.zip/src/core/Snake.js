export class Snake {
    constructor(config) {
        this.segments = [];
        this.direction = 'right';
        this.speed = config.speed;
        
        this.init(config.initialSnakeLength);
    }
    
    init(length) {
        // 初始化蛇的身体
        for (let i = 0; i < length; i++) {
            this.segments.push({
                x: 100 - (i * 20),
                y: 100
            });
        }
    }
    
    setDirection(direction) {
        // 防止直接反向
        const opposites = {
            'up': 'down',
            'down': 'up',
            'left': 'right',
            'right': 'left'
        };
        
        if (opposites[direction] !== this.direction) {
            this.direction = direction;
        }
    }
    
    update() {
        // 移动蛇
        const head = { ...this.segments[0] };
        
        switch (this.direction) {
            case 'up':
                head.y -= this.speed;
                break;
            case 'down':
                head.y += this.speed;
                break;
            case 'left':
                head.x -= this.speed;
                break;
            case 'right':
                head.x += this.speed;
                break;
        }
        
        this.segments.unshift(head);
        this.segments.pop();
    }
} 
import * as PIXI from 'pixi.js';
import { Snake } from './Snake.js';
import { PhysicsWorld } from '../physics/PhysicsWorld.js';
import { Renderer } from '../graphics/Renderer.js';

export class Game {
    constructor(config) {
        this.config = config;
        this.snake = null;
        this.physicsWorld = null;
        this.renderer = null;
        this.gameState = {
            score: 0,
            isGameOver: false,
            isPaused: false
        };
        
        this.init();
    }
    
    init() {
        // 初始化 PIXI 应用
        this.app = new PIXI.Application({
            width: this.config.width,
            height: this.config.height,
            backgroundColor: 0xFFFFFF,
            view: document.getElementById('gameCanvas')
        });
        
        // 初始化物理引擎
        this.physicsWorld = new PhysicsWorld();
        
        // 初始化渲染器
        this.renderer = new Renderer(this.app);
        
        // 初始化蛇
        this.snake = new Snake(this.config);
        
        // 设置键盘控制
        this.setupControls();
    }
    
    setupControls() {
        window.addEventListener('keydown', (e) => {
            switch(e.key) {
                case 'ArrowUp':
                    this.snake.setDirection('up');
                    break;
                case 'ArrowDown':
                    this.snake.setDirection('down');
                    break;
                case 'ArrowLeft':
                    this.snake.setDirection('left');
                    break;
                case 'ArrowRight':
                    this.snake.setDirection('right');
                    break;
            }
        });
    }
    
    start() {
        this.gameLoop();
    }
    
    gameLoop() {
        if (!this.gameState.isGameOver && !this.gameState.isPaused) {
            this.update();
            this.render();
        }
        requestAnimationFrame(() => this.gameLoop());
    }
    
    update() {
        this.snake.update();
        this.physicsWorld.update();
        this.checkCollisions();
    }
    
    render() {
        this.renderer.renderScene([this.snake]);
    }
    
    checkCollisions() {
        // 碰撞检测逻辑
    }
} 
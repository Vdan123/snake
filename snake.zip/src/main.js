import { Game } from './core/Game.js';

let game = null;

window.onload = () => {
    const config = {
        width: 800,
        height: 600,
        initialSnakeLength: 3,
        speed: 5
    };
    
    const startButton = document.getElementById('startButton');
    startButton.addEventListener('click', () => {
        if (game) {
            // 重置游戏
            game = null;
        }
        game = new Game(config);
        game.start();
        startButton.textContent = '重新开始';
    });
}; 